﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameBook
{
    class Option
    {
        // TODO: finish this by yourself
        public string text;
        public int pageNum;
    }
}
