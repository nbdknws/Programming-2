﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameBook
{
    class Page
    {
        public int pageNum;
        public string text;
        public List<Option> options;       
    }
}
